class AppImages {
  AppImages._private();
  static const avatar = "assets/images/avatar.jpg";
}
