class AppIcons {
  AppIcons._private();
  static const check = 'assets/icons/check.png';
  static const uncheck = 'assets/icons/uncheck.png';
  static const calendar = 'assets/icons/calendar.png';
  static const plus = 'assets/icons/plus.png';
  static const search = 'assets/icons/search.png';
  static const back = 'assets/icons/back.png';
  static const clock = 'assets/icons/clock.png';
  static const on = 'assets/icons/On.png';
  static const leftArrow = 'assets/icons/left_arrow.png';
  static const rightArrow = 'assets/icons/right_arrow.png';
}
